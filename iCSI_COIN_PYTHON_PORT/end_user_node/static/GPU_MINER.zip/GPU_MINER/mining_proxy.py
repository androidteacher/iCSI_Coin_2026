#!/usr/bin/env python3
"""
iCSI Coin GPU Mining Proxy
==========================

ccminer speaks the old HTTP "getwork" protocol; an iCSI Coin node speaks
JSON-RPC ("getblocktemplate" / "submitblock"). This small proxy sits between
them:

    ccminer  --getwork-->  mining_proxy.py  --getblocktemplate/submitblock-->  node

It asks the node for a block template (telling the node to pay YOU by injecting
your wallet address), hands ccminer an 80-byte header to grind on, and when
ccminer finds a winning nonce it rebuilds the full block and submits it.

------------------------------------------------------------------------------
CONFIGURE TWO THINGS:
  1. Your WALLET ADDRESS  -> passed as the first command-line argument
                             (run_miner.bat does this for you).
  2. Your NODE's ADDRESS  -> edit NODE_URL below (or pass it as the 2nd argument).
------------------------------------------------------------------------------

This file is self-contained: it needs only Python 3's standard library (the
`scrypt` package is optional and only used for a local sanity check).
"""

import sys
import json
import struct
import binascii
import urllib.request
import urllib.error
import threading
from http.server import BaseHTTPRequestHandler
from socketserver import ThreadingMixIn, TCPServer

# ─────────────────────────── CONFIGURATION ───────────────────────────
# Port this proxy listens on for ccminer, here on THIS Windows PC. ccminer
# connects here (run_miner.bat uses: -o http://127.0.0.1:9340). Do NOT change.
LOCAL_PORT = 9340

# ==================  >>> YOU MUST CHANGE THIS LINE <<<  ==================
# The GPU miner runs on THIS Windows PC. Your iCSI Coin node runs on a
# SEPARATE Linux machine. Put that Linux machine's IP address below.
#
#   * It is almost never 127.0.0.1 -- that would mean the node is on THIS PC.
#   * Find the IP ON THE LINUX NODE by running:   hostname -I
#   * Keep the ":9342" at the end (the node's RPC port). Example:
#
#         NODE_URL = "http://192.168.1.50:9342"
#
NODE_URL = "http://PUT_YOUR_LINUX_NODE_IP_HERE:9342"
# ========================================================================

MINING_ADDRESS = None

# Cache of jobs we handed out, so we can rebuild the full block on submit.
# Keyed by the 80-byte header hex; stores the template it came from.
JOB_CACHE = {}
CACHE_LOCK = threading.Lock()


# ───────────────────────── serialization helpers ─────────────────────
# These reproduce the node's block serialization EXACTLY (see
# icsicoin/core/serialization.py and core/primitives.py) so the block we
# submit hashes to the same value the node validates. All little-endian.

def _u32(n):
    return struct.pack('<I', n)

def _compact_size(n):
    """Bitcoin CompactSize / VarInt (used for the transaction count)."""
    if n < 0xfd:
        return struct.pack('<B', n)
    elif n <= 0xffff:
        return b'\xfd' + struct.pack('<H', n)
    elif n <= 0xffffffff:
        return b'\xfe' + struct.pack('<I', n)
    else:
        return b'\xff' + struct.pack('<Q', n)

def build_block_header(version, prev_block, merkle_root, timestamp, bits, nonce):
    """Serialize an 80-byte block header, byte-identical to BlockHeader.serialize()."""
    return (
        _u32(version) +
        prev_block +          # 32 bytes, as-is
        merkle_root +         # 32 bytes, as-is
        _u32(timestamp) +
        _u32(bits) +
        _u32(nonce)
    )

def build_work_from_template(tmpl):
    """
    Turn a getblocktemplate result into ccminer 'getwork' data.

    Returns (data_hex, target_le_hex, header_bytes) where:
      * data_hex      : 128-byte work (80-byte header + 48 bytes padding), hex
      * target_le_hex : the target in the little-endian order getwork expects
      * header_bytes  : the raw 80-byte header (for the job cache)
    """
    header_bytes = build_block_header(
        tmpl['version'],
        binascii.unhexlify(tmpl['previousblockhash']),
        binascii.unhexlify(tmpl['merkle_root']),
        tmpl['curtime'],
        tmpl['bits'],
        0,  # nonce starts at 0; ccminer grinds it
    )
    # getwork data is 128 bytes (header + zero padding). No byte-swap: ccminer is
    # configured for scrypt and hashes these bytes directly, matching the node.
    data = header_bytes + b'\x00' * 48

    # Node gives the target big-endian; getwork wants it little-endian.
    target_le = binascii.unhexlify(tmpl['target'])[::-1].hex()
    return data.hex(), target_le, header_bytes

def reconstruct_block_hex(submitted_data_hex, tmpl):
    """
    Rebuild the full block for 'submitblock' from the winning work ccminer
    returned plus the transactions from the template.

    block = winning 80-byte header + CompactSize(tx_count) + every tx (raw).
    The template's transaction hexes are already the node's exact tx bytes, so
    concatenating them reproduces the node's block body precisely.
    """
    submitted = binascii.unhexlify(submitted_data_hex)
    header_bytes = submitted[:80]            # header incl. the winning nonce
    tx_hexes = tmpl['transactions']          # [coinbase, ...], already serialized
    body = _compact_size(len(tx_hexes)) + b''.join(binascii.unhexlify(h) for h in tx_hexes)
    return binascii.hexlify(header_bytes + body).decode('utf-8')


# ───────────────────────────── RPC to node ───────────────────────────
def rpc_call(method, params=None, node_url=None):
    node_url = node_url or NODE_URL
    payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or []}
    req = urllib.request.Request(
        node_url, data=json.dumps(payload).encode('utf-8'),
        headers={'Content-Type': 'application/json'},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.loads(response.read())
    except Exception as e:
        print(f"RPC Error ({method}): {e}")
        return None


# ───────────────────────────── HTTP handler ──────────────────────────
class ProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # quiet default access logging

    def do_POST(self):
        try:
            length = int(self.headers.get('Content-Length', 0))
            req_json = json.loads(self.rfile.read(length))
        except Exception as e:
            self.send_error(400, f"Bad request: {e}")
            return

        method = req_json.get('method')
        req_id = req_json.get('id')
        params = req_json.get('params')
        print(f"-> Request: {method}")

        if method == 'getwork':
            if not params:
                result = self.handle_getwork_request()
            else:
                result = self.handle_getwork_submit(params[0])
            self.send_json_response(result, req_id)
            return

        # Anything else: forward to the node as-is.
        self.passthrough(req_json)

    def send_json_response(self, result, req_id):
        body = json.dumps({"result": result, "error": None, "id": req_id}).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def handle_getwork_request(self):
        resp = rpc_call("getblocktemplate", [{"mining_address": MINING_ADDRESS}])
        if not resp or not resp.get('result'):
            print("   Failed to get block template from node")
            return None
        tmpl = resp['result']

        data_hex, target_le, header_bytes = build_work_from_template(tmpl)

        with CACHE_LOCK:
            if len(JOB_CACHE) > 50:
                JOB_CACHE.clear()
            JOB_CACHE[header_bytes.hex()] = tmpl

        print(f"   [Getwork] Job from height {tmpl['height']}  (reward -> {MINING_ADDRESS})")
        return {"data": data_hex, "target": target_le, "algorithm": "scrypt"}

    def handle_getwork_submit(self, data_hex):
        print("-> [Getwork] Share submitted")
        try:
            header_bytes = binascii.unhexlify(data_hex)[:80]
        except Exception as e:
            print(f"   Bad submit data: {e}")
            return False

        # Match this share to the job we handed out (prev_block + merkle_root,
        # i.e. the header minus the mutable timestamp/bits/nonce tail).
        prev_merkle = header_bytes[4:68]
        tmpl = None
        with CACHE_LOCK:
            for cached_hex, cached_tmpl in JOB_CACHE.items():
                if bytes.fromhex(cached_hex)[4:68] == prev_merkle:
                    tmpl = cached_tmpl
                    break
        if tmpl is None:
            print("   Stale/unknown share (no matching job)")
            return False

        block_hex = reconstruct_block_hex(data_hex, tmpl)
        resp = rpc_call("submitblock", [block_hex])
        if resp and resp.get('result') == 'accepted':
            print(f"   *** BLOCK ACCEPTED at height {tmpl['height']}! ***")
            return True
        print(f"   Block rejected: {resp}")
        return False

    def passthrough(self, req_json):
        try:
            body = json.dumps(req_json).encode('utf-8')
            req = urllib.request.Request(
                NODE_URL, data=body, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=15) as response:
                data = response.read()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except urllib.error.HTTPError as e:
            self.send_response(e.code)
            self.end_headers()
            self.wfile.write(e.read())
        except Exception as e:
            print(f"   Passthrough error: {e}")
            self.send_error(500, str(e))


class ThreadingHTTPServer(ThreadingMixIn, TCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    global MINING_ADDRESS, NODE_URL
    if len(sys.argv) < 2 or not sys.argv[1]:
        print("Usage: python mining_proxy.py <WALLET_ADDRESS> [NODE_URL]")
        print("  e.g. python mining_proxy.py 86fd480a7925feb9b370e38245db743caa694fd5")
        print("       python mining_proxy.py <addr> http://192.168.1.50:9342")
        sys.exit(1)

    MINING_ADDRESS = sys.argv[1].strip()
    if len(sys.argv) > 2 and sys.argv[2].strip():
        node = sys.argv[2].strip()
        NODE_URL = node if node.startswith("http") else f"http://{node}:9342"

    # Refuse to run until the node IP has actually been set.
    if "PUT_YOUR_LINUX_NODE_IP_HERE" in NODE_URL:
        print("ERROR: You have not set your node's IP address yet.")
        print("  The GPU miner runs on Windows; your iCSI Coin node runs on Linux.")
        print("  On the LINUX node, run:   hostname -I   to get its IP address, then")
        print("  either:")
        print('    * edit mining_proxy.py and set  NODE_URL = "http://<that-ip>:9342"')
        print("    * or pass it on the command line:")
        print("        python mining_proxy.py <WALLET_ADDRESS> http://<that-ip>:9342")
        sys.exit(1)

    print("=" * 60)
    print("  iCSI Coin GPU Mining Proxy")
    print("=" * 60)
    print(f"  Listening for ccminer on : http://127.0.0.1:{LOCAL_PORT}")
    print(f"  Forwarding to node       : {NODE_URL}")
    print(f"  Paying rewards to wallet : {MINING_ADDRESS}")
    print("=" * 60)

    with ThreadingHTTPServer(("", LOCAL_PORT), ProxyHandler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nProxy stopped.")


if __name__ == '__main__':
    main()
