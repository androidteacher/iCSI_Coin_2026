import http.server
import socketserver
import json
import urllib.request
import urllib.error
import sys
import struct
import binascii
import time
import threading

# Configuration
LOCAL_PORT = 9340
NODE_URL = "http://192.168.228.69:9342"
MINING_ADDRESS = None

# Job Cache: { "job_id": { "txs": [...], "header_prefix": bytes, "header_suffix": bytes, "target": int } }
# We need this to reconstruct the block when share is found.
# For simplicity in 'getwork', we might not get a job_id back, so we might have to assume checking against recent templates.
# 'getwork' usually returns data, target. Miner returns data (with nonce changed).
# We can map data_prefix -> Template.
JOB_CACHE = {}
CACHE_LOCK = threading.Lock()

if len(sys.argv) > 1:
    MINING_ADDRESS = sys.argv[1]

if not MINING_ADDRESS:
    print("Error: Usage: python mining_proxy.py <MINING_ADDRESS>")
    sys.exit(1)

print(f"Starting Proxy on port {LOCAL_PORT} -> Node {NODE_URL}")
print(f"Injecting Mining Address: {MINING_ADDRESS}")
print("Mode: Getwork <-> Getblocktemplate Adapter")

def rpc_call(method, params=None):
    if params is None: params = []
    payload = {
        "method": method,
        "params": params,
        "jsonrpc": "2.0",
        "id": 1
    }
    headers = {'Content-Type': 'application/json'}
    req = urllib.request.Request(NODE_URL, data=json.dumps(payload).encode('utf-8'), headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read())
    except Exception as e:
        print(f"RPC Error ({method}): {e}")
        return None

# Helpers from primitives.py/miner.py logic
import os
# Add path to icsicoin module
# Assuming structure:
# GPUMINER/GPU_MINER/mining_proxy.py
# GPUMINER/iCSI_Coin_2026-main/iCSI_Coin_2026-main/iCSI_COIN_PYTHON_PORT/end_user_node/icsicoin
# We need to add .../end_user_node to sys.path

current_dir = os.path.dirname(os.path.abspath(__file__))
# current_dir = .../GPUMINER/GPU_MINER
# We need .../GPUMINER
gpu_miner_root = os.path.dirname(current_dir)

# Path to end_user_node
node_path = os.path.join(gpu_miner_root, "iCSI_Coin_2026-main", "iCSI_Coin_2026-main", "iCSI_COIN_PYTHON_PORT", "end_user_node")
if node_path not in sys.path:
    sys.path.append(node_path)

try:
    from icsicoin.core.primitives import BlockHeader, Block, Transaction
    import io
    print("Successfully imported icsicoin primitives")
except ImportError as e:
    print(f"Failed to import icsicoin primitives: {e}")
    print(f"Checked path: {node_path}")
    sys.exit(1)

def encode_uint32(x): return struct.pack('<I', x)

def byte_swap(data):
    # Disable Swap for Scrypt/Ccminer (Test Config)
    return data

class ProxyHandler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            req_json = json.loads(post_data)
            method = req_json.get('method')
            params = req_json.get('params')
            req_id = req_json.get('id')
            
            print(f"-> Request: {method}")

            if method == 'getwork':
                # Handle Getwork Wrapper
                if not params:
                    # Request for work
                    response = self.handle_getwork_request()
                else:
                    # Submission of work
                    response = self.handle_getwork_submit(params[0])
                    
                self.send_json_response(response, req_id)
                return

            # Passthrough for anything else
            print(f"-> Passthrough: {method}")
            
            # Map Methods if needed
            original_method = method
            if method == 'getmininginfo':
                # Node doesn't support getmininginfo, map to getinfo
                print("   Mapping getmininginfo -> getinfo")
                req_json['method'] = 'getinfo'
                
            # Forward to Node
            headers = {'Content-Type': 'application/json'}
            # Strip Auth
            
            try:
                req_body = json.dumps(req_json).encode('utf-8')
                req = urllib.request.Request(NODE_URL, data=req_body, headers=headers)
                
                with urllib.request.urlopen(req) as response:
                    resp_data = response.read()
                    
                    # Transform Response if it was getblocktemplate
                    if original_method == 'getblocktemplate':
                        try:
                            resp_json = json.loads(resp_data)
                            if resp_json.get('result') and 'transactions' in resp_json['result']:
                                result = resp_json['result']
                                txs = result['transactions']
                                if txs and len(txs) > 0:
                                    coinbase_hex = txs[0]
                                    result['coinbasetxn'] = { "data": coinbase_hex }
                                    result['transactions'] = txs[1:]
                                    resp_data = json.dumps(resp_json).encode('utf-8')
                                    print("   Transformed GBT response (coinbase extracted)")
                        except Exception as e:
                            print(f"Error transforming GBT: {e}")

                    # Send back
                    self.send_response(response.status)
                    for k, v in response.getheaders():
                        if k.lower() not in ['transfer-encoding', 'content-length', 'connection']:
                            self.send_header(k, v)
                    
                    self.send_header('Content-Length', str(len(resp_data)))
                    self.end_headers()
                    self.wfile.write(resp_data)
                    
            except urllib.error.HTTPError as e:
                self.send_response(e.code)
                self.end_headers()
                self.wfile.write(e.read())
            except Exception as e:
                print(f"Passthrough Error: {e}")
                self.send_error(500, str(e))
            
        except Exception as e:
            print(f"Error: {e}")
            self.send_error(500, str(e))

    def send_json_response(self, result, req_id):
        resp = {
            "result": result,
            "error": None,
            "id": req_id
        }
        resp_bytes = json.dumps(resp).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(resp_bytes)))
        self.end_headers()
        self.wfile.write(resp_bytes)

    def handle_getwork_request(self):
        # 1. Get Template
        gbt_resp = rpc_call("getblocktemplate", [{"mining_address": MINING_ADDRESS}])
        if not gbt_resp or not gbt_resp.get('result'):
            print("Failed to get block template")
            return None
        
        tmpl = gbt_resp['result']
        
        # 2. Build Header using OFFICIAL primitives
        version = tmpl['version']
        prev_hash = binascii.unhexlify(tmpl['previousblockhash'])
        merkle_root = binascii.unhexlify(tmpl['merkle_root'])
        curtime = tmpl['curtime']
        bits = tmpl['bits']
        nonce = 0
        
        # Use existing timestamp/bits from template (ints)
        
        header_obj = BlockHeader(version, prev_hash, merkle_root, curtime, bits, nonce)
        header_bytes = header_obj.serialize()
        
        # 3. Pad to 128 bytes
        data_le = header_bytes + b'\x00' * 48
         
        # BYTE SWAP for Miner (Enabled for standard getwork)
        data_miner = byte_swap(data_le)
        
        target = tmpl['target'] # Hex string
        
        # Scrypt Sanity Check
        try:
             import scrypt
             header_bytes_chk = header_bytes
             # Hash like Node
             pow_hash = scrypt.hash(header_bytes_chk, header_bytes_chk, N=1024, r=1, p=1, buflen=32)
             pow_hex = binascii.hexlify(pow_hash).decode('utf-8')
             print(f"   [Sanity] Local Hash: {pow_hex[:16]}...")
             
             target_int = int(target, 16)
             pow_int = int.from_bytes(pow_hash, 'little')
             
             diff_ok = pow_int <= target_int
             print(f"   [Sanity] Against Target(BE): {'PASS' if diff_ok else 'FAIL'}")
        except Exception as e:
             print(f"   [Sanity] Could not run local check: {e}")
        
        # Reversing Target to Little Endian
        target_bytes = binascii.unhexlify(target)
        target_le = target_bytes[::-1].hex()
        
        print(f"   [Getwork] Created Job from Height {tmpl['height']}")
        print(f"   [Getwork] Target (Node/BE):  {target[:16]}...")
        print(f"   [Getwork] Target (Miner/LE): {target_le[:16]}...")
        print(f"   [Getwork] Data (Miner/LE):   {data_miner.hex()[:16]}...")
        
        # Store in Cache for submission
        with CACHE_LOCK:
            key = data_miner.hex()
            job_info = {
                "tmpl": tmpl,
                "header_obj": header_obj # Store Object
            }
            if len(JOB_CACHE) > 50: JOB_CACHE.clear()
            JOB_CACHE[data_miner[:160].hex()] = job_info
            
        return {
            "data": data_miner.hex(),
            "target": target_le,
            "algorithm": "scrypt"
        }

    def handle_getwork_submit(self, data_hex):
        print(f"-> [Getwork] SUBMIT handling...")
        # 1. Parse Data
        data_miner = binascii.unhexlify(data_hex)
        data_le = byte_swap(data_miner)
        header_bytes = data_le[:80]
        
        # 2. Find Job
        # We need to find valid template to get TXs.
        # We can try to deserialize the header using primitives to get fields.
        try:
             # BlockHeader.deserialize expects a file-like object
             submit_header_obj = BlockHeader.deserialize(io.BytesIO(header_bytes))
        except Exception as e:
             print(f"Failed to deserialize submitted header: {e}")
             return False

        # Match by prev_block and merkle_root
        match_prev = submit_header_obj.prev_block
        match_merkle = submit_header_obj.merkle_root
        
        found_job = None
        with CACHE_LOCK:
            for k, v in JOB_CACHE.items():
                cached_obj = v['header_obj']
                if cached_obj.prev_block == match_prev and cached_obj.merkle_root == match_merkle:
                    found_job = v
                    break
        
        if not found_job:
            print("Stale or unknown work submission (Header match failed)")
            print(f"   Submitted Prev: {match_prev.hex()[:16]}...")
            return False
            
        tmpl = found_job['tmpl']
        
        # 3. Reconstruct VALID Block using Primitives
        # We have the header with the winning nonce from miner (submit_header_obj).
        # We have the transactions from the template.
        
        # Deserialize transactions
        txs = []
        for tx_hex in tmpl['transactions']:
            tx_bytes = binascii.unhexlify(tx_hex)
            txs.append(Transaction.deserialize(io.BytesIO(tx_bytes)))
            
        # Create Block Object
        block_obj = Block(submit_header_obj, txs)
        
        # Serialize Full Block
        block_bytes = block_obj.serialize()
        block_hex_submit = binascii.hexlify(block_bytes).decode('utf-8')
        
        print(f"Submitting Block! Nonce: {submit_header_obj.nonce}")
        
        # 4. Submit
        resp = rpc_call("submitblock", [block_hex_submit])
        
        if resp and resp.get('result') == 'accepted':
            print("Block ACCEPTED!")
            return True
        else:
            print(f"Block Rejected: {resp}")
            return False

with socketserver.TCPServer(("", LOCAL_PORT), ProxyHandler) as httpd:
    httpd.serve_forever()
