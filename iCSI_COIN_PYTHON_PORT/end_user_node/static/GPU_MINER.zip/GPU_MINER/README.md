# iCSI_Coin GPU Miner (Proxy Edition)

This folder contains a GPU miner pre-configured for **iCSI_Coin**. It uses `ccminer` combined with a Python proxy to ensure mining rewards are correctly credited to your wallet.

## Prerequisites
1.  **Python 3.x Installed** (Required for the proxy).
2.  **NVIDIA GPU** with up-to-date drivers.
3.  **iCSI_Coin Node** running locally on port 9340.

## Setup
1.  **Edit `run_miner.bat`**:
    -   Right-click `run_miner.bat` and select **Edit**.
    -   Find the line `set ADDRESS=<YOUR_WALLET_ADDRESS>`.
    -   Replace `<YOUR_WALLET_ADDRESS>` with your actual iCSI_Coin wallet address.
    -   Save the file.

## Usage
Double-click `run_miner.bat`.

### What happens?
1.  It launches a **Mining Proxy** window (`python mining_proxy.py`). This script listens on port **9340** and forwards requests to your node on **9342**, injecting your wallet address into every job request.
2.  It launches **ccminer** which connects to this proxy.

## Troubleshooting
- **"python is not recognized"**: Install Python and add it to your PATH.
- **"Connection refused"**: Ensure your node is running.
- **Hashrate shows 0**: Wait a few seconds for the first job to be processed.
