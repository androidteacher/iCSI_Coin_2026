# iCSI Coin — GPU Miner (Proxy Edition)

Mine **iCSI Coin** with your NVIDIA GPU. This bundle contains the `ccminer`
GPU miner plus a tiny Python **proxy** that connects it to your iCSI Coin node
and makes sure every block reward is paid to **your** wallet.

> ### ⚠️ Two different machines!
> This GPU miner runs on your **Windows PC**. Your iCSI Coin **node** runs on a
> separate **Linux machine**. You must tell the miner the **IP address of that
> Linux node** (see step 2 below). It is **not** `127.0.0.1`.

---

## How it works (the 30-second version)

`ccminer` only speaks the old **getwork** mining protocol, but an iCSI Coin node
speaks **JSON-RPC**. `mining_proxy.py` sits in the middle and translates:

```
   [ WINDOWS PC ]                                   [ LINUX NODE ]
   ccminer  ──getwork──►  mining_proxy.py  ──getblocktemplate / submitblock──►  node
   (your GPU)             (127.0.0.1:9340)        (http://<LINUX_NODE_IP>:9342)
```

The proxy asks your node for work, **injects your wallet address** so the reward
is yours, hands the GPU an 80-byte header to grind, and when a winning share
comes back it rebuilds the full block and submits it to the node.

> The proxy is self-contained — it only needs Python 3's standard library. You do
> **not** need a copy of the node source code next to it.

---

## Prerequisites

1. **Windows** with an **NVIDIA GPU** and current drivers.
2. **Python 3** installed and on your PATH (used only by the proxy).
   - Check: open a Command Prompt and run `python --version`.
3. A **running iCSI Coin node** (on your **Linux machine**) that this Windows PC
   can reach on the node's RPC port **9342**. The Windows PC and the Linux node
   must be on the **same network** (e.g. the same LAN/Wi-Fi).

---

## Setup — two things to configure

### 1. Your wallet address  (in `run_miner.bat`)
- Right-click **`run_miner.bat`** → **Edit**.
- Find the line:
  ```bat
  set ADDRESS=<YOUR_WALLET_ADDRESS>
  ```
- Replace `<YOUR_WALLET_ADDRESS>` with your iCSI Coin wallet address
  (the 40-character address shown in your node's web wallet, e.g.
  `86fd480a7925feb9b370e38245db743caa694fd5`).
- Save.

### 2. Your Linux node's IP address  (in `mining_proxy.py`)  ← the important one
**First, get the node's IP.** On your **Linux node**, open a terminal and run:
```bash
hostname -I
```
It prints something like `192.168.1.50` (use the first address).

**Then set it in the proxy:**
- Right-click **`mining_proxy.py`** → **Edit**.
- Near the top, find the big `YOU MUST CHANGE THIS LINE` block and the line:
  ```python
  NODE_URL = "http://PUT_YOUR_LINUX_NODE_IP_HERE:9342"
  ```
- Replace `PUT_YOUR_LINUX_NODE_IP_HERE` with your node's IP, keeping `:9342`:
  ```python
  NODE_URL = "http://192.168.1.50:9342"
  ```
- Save.

> The proxy **will refuse to start** until you change this — so you can't forget.
>
> Tip: instead of editing the file you can pass the IP on the command line:
> `python mining_proxy.py <WALLET_ADDRESS> http://192.168.1.50:9342`

---

## Run it

Double-click **`run_miner.bat`**. Two things happen:

1. A **Mining Proxy** window opens and prints:
   ```
   Listening for ccminer on : http://127.0.0.1:9340
   Forwarding to node       : http://192.168.1.50:9342   (your Linux node's IP)
   Paying rewards to wallet : 86fd480a7925...
   ```
2. **ccminer** starts and connects to the proxy.

### What success looks like
- The **proxy** window prints a line like `-> Request: getwork` and
  `[Getwork] Job from height 1234 (reward -> <your address>)` each time ccminer
  asks for work.
- **ccminer** shows a hashrate (e.g. `kH/s`) once it's grinding.
- When your GPU finds a block, the proxy prints
  **`*** BLOCK ACCEPTED at height N! ***`** and your wallet balance goes up on the
  node's web page (after the coinbase matures).

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `python is not recognized` | Install Python 3 and tick **"Add to PATH"**, then reopen the Command Prompt. |
| `RPC Error ... Connection refused` | Your node isn't running, or `NODE_URL` is wrong. Confirm the node is up and the IP/port are reachable. |
| Remote node won't connect | Make sure that PC's firewall allows inbound **TCP 9342**, and the node is bound to `0.0.0.0` (the default). |
| Proxy says `Failed to get block template` | The node is reachable but returned no work — check the node's RPC is on **9342**. |
| ccminer hashes but blocks are `rejected` | Your wallet address must be the **40-hex** node address (not a script, not a Bitcoin-style address). Re-copy it from the node's wallet. |
| Hashrate shows 0 for a while | Normal at startup — give it a few seconds for the first job. |

---

## Note for maintainers / advanced users

The proxy builds the 80-byte header and reconstructs the block using the node's
**exact** little-endian serialization, so a block it submits is byte-for-byte
what the node expects and passes full consensus validation (Proof of Work,
difficulty, merkle root, and coinbase subsidy) — this has been verified
end-to-end against the node. The one thing that can only be confirmed by a real
run is `ccminer`'s own internal byte handling for scrypt getwork: if ccminer
ever reports shares that the proxy logs as `rejected` even though the node is
healthy, the header byte order handed to the miner (`build_work_from_template`)
is the place to look.
