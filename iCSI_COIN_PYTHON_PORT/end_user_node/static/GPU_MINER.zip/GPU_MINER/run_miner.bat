@echo off
REM ============================================================
REM  iCSI Coin GPU Miner
REM  Before running, set TWO things:
REM    1) Your wallet address  -> below in this file
REM    2) Your node's IP/URL   -> NODE_URL inside mining_proxy.py
REM ============================================================

REM --- EDIT THIS: paste YOUR iCSI Coin wallet address between the = and the end of line ---
set ADDRESS=<YOUR_WALLET_ADDRESS>

if "%ADDRESS%"=="<YOUR_WALLET_ADDRESS>" (
    echo [STOP] You have not set your wallet address yet!
    echo Edit run_miner.bat and replace ^<YOUR_WALLET_ADDRESS^> with your address.
    pause
    exit /b
)

echo Starting Mining Proxy...
start "iCSI Mining Proxy" cmd /k python mining_proxy.py %ADDRESS%

echo Waiting for proxy to initialize...
timeout /t 3 >nul

echo Starting ccminer (connecting to the proxy at http://127.0.0.1:9340)...
ccminer-x64.exe -a scrypt -o http://127.0.0.1:9340 -u user -p pass --no-stratum --no-autotune

pause
